$(document).ready(function(){
	// 01 Toggle Navigation
	$(".togglebtn").click(function(){
		$(".navigation").slideToggle();
	})
	// 02 ScrollUp Page
	$(window).scroll(function(){
		if($(this).scrollTop() > 300){
			$(".scrollup").fadeIn();
		}
		else{
			$(".scrollup").fadeOut();	
		}
	})
	$(".scrollup").click(function(){
		$("html,body").animate({scrollTop:0},400);
		return false();
	});
	// 03 Favicon icon 
	$('head').append('<link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon" />');
	
	// 04 Load favicon


});

	
    
  

